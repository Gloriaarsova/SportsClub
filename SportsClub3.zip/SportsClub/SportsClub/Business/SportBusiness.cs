﻿using SportsClub.Data;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SportsClub.Business
{
    public class SportBusiness
    {
        private SportsClubContext sportsClubContext;
        public List<Sport> GetAll()
        {
            using(sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Sport.ToList();
            }
        }

        public Sport Get(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Sport.Find(id);
            }
        }

        public void Add(Sport sport)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                sportsClubContext.Sport.Add(sport);
                sportsClubContext.SaveChanges();
            }
        }

        public void Update(Sport sport)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Sport.Find(sport.Id);
                if(item!=null)
                {
                    sportsClubContext.Entry(item).CurrentValues.SetValues(sport);
                    sportsClubContext.SaveChanges();
                }
                
            }
        }

        public void Delete(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Sport.Find(id);
                if (item != null)
                {
                    sportsClubContext.Sport.Remove(item);
                    sportsClubContext.SaveChanges();
                }

            }
        }

    }
}
