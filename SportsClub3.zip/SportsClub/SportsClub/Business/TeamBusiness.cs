﻿using SportsClub.Data;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SportsClub.Business
{
    public class TeamBusiness
    {
        private SportsClubContext sportsClubContext;
        public List<Team> GetAll()
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Team.ToList();
            }
        }

        public Team Get(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Team.Find(id);
            }
        }

        public void Add(Team team)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                sportsClubContext.Team.Add(team);
                sportsClubContext.SaveChanges();
            }
        }

        public void Update(Team team)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Team.Find(team.Id);
                if (item != null)
                {
                    sportsClubContext.Entry(item).CurrentValues.SetValues(team);
                    sportsClubContext.SaveChanges();
                }

            }
        }

        public void Delete(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Team.Find(id);
                if (item != null)
                {
                    sportsClubContext.Team.Remove(item);
                    sportsClubContext.SaveChanges();
                }

            }
        }
    }
}
