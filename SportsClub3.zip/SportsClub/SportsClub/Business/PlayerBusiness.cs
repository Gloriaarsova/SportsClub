﻿using SportsClub.Data;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SportsClub.Business
{
    public class PlayerBusiness
    {
        private SportsClubContext sportsClubContext;
        public List<Player> GetAll()
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Player.ToList();
            }
        }

        public Player Get(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Player.Find(id);
            }
        }

        public void Add(Player player)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                sportsClubContext.Player.Add(player);
                sportsClubContext.SaveChanges();
            }
        }

        public void Update(Player player)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Player.Find(player.Id);
                if (item != null)
                {
                    sportsClubContext.Entry(item).CurrentValues.SetValues(player);
                    sportsClubContext.SaveChanges();
                }

            }
        }

        public void Delete(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Player.Find(id);
                if (item != null)
                {
                    sportsClubContext.Player.Remove(item);
                    sportsClubContext.SaveChanges();
                }

            }
        }
    }
}
