﻿using SportsClub.Data;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SportsClub.Business
{
    public class TrainerBusiness
    {
        private SportsClubContext sportsClubContext;
        public List<Trainer> GetAll()
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Trainer.ToList();
            }
        }

        public Trainer Get(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                return sportsClubContext.Trainer.Find(id);
            }
        }

        public void Add(Trainer trainer)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                sportsClubContext.Trainer.Add(trainer);
                sportsClubContext.SaveChanges();
            }
        }

        public void Update(Trainer trainer)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Trainer.Find(trainer.Id);
                if (item != null)
                {
                    sportsClubContext.Entry(item).CurrentValues.SetValues(trainer);
                    sportsClubContext.SaveChanges();
                }

            }
        }

        public void Delete(int id)
        {
            using (sportsClubContext = new SportsClubContext())
            {
                var item = sportsClubContext.Trainer.Find(id);
                if (item != null)
                {
                    sportsClubContext.Trainer.Remove(item);
                    sportsClubContext.SaveChanges();
                }

            }
        }
    }
}
