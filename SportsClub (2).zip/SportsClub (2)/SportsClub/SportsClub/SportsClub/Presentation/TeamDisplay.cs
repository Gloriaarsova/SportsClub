﻿using ConsoleTables;
using SportsClub.Business;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SportsClub.Presentation
{
    /// <summary>
    /// In class "TeamDisplay" are implemented the methods, which describe how the team information is displayed
    /// </summary>
    public class TeamDisplay
    {
        private TeamBusiness teamBusiness = new TeamBusiness();
        private TrainerBusiness trainerBusiness = new TrainerBusiness();
        private SportBusiness sportBusiness = new SportBusiness();

        /// <summary>
        /// Method "TeamDisplay" allows us to use the functions we choose
        /// </summary>
        public TeamDisplay()
        {
            var operation = -1;

            do
            {
                Console.Clear();
                Console.WriteLine("-- Teams --");
                Display.ShowActions();

                try
                {
                    operation = Display.GetIntNumber(operation);//gets the number which we entered

                    Console.Clear();

                    switch (operation)
                    {
                        case 1:
                            {
                                ListAll();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 2:
                            {
                                Add();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 3:
                            {
                                Update();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 4:
                            {
                                FetchById();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 5:
                            {
                                Delete();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 6:
                            {
                                FetchByName();
                                Display.GetBackToMenu();
                                break;
                            }
                        default:
                            {
                                if (operation != Display.actionExitOperation)//checks if the number which we eneterd in not in the menu
                                {
                                    Console.WriteLine("Not an operation number");
                                    Display.GetBackToMenu();
                                }
                                break;
                            }
                    }
                }
                catch (ArgumentException exception)
                {
                    Console.WriteLine(exception.Message);
                    Display.GetBackToMenu();
                }
            } while (operation != Display.actionExitOperation);
        }

        /// <summary>
        /// Method "ListAll" shows a list of all teams and the information about them
        /// </summary>
        private void ListAll()
        {
            Console.WriteLine("Teams:");
            List<Team> teams = teamBusiness.GetAll();

            if (teams.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Name", "Sport", "Trainer");

                foreach (var item in teams)
                {
                    var sport = sportBusiness.Get(item.SportId);
                    var trainer = trainerBusiness.Get(item.TrainerId);
                    table.AddRow(item.Id, item.Name, sport.Name, trainer.Name);
                }

                table.Write();               
            }
            else
            {
                Console.WriteLine("No teams");
            }
        }

        /// <summary>
        /// Method "Add" adds a new team to the database
        /// </summary>
        private void Add()
        {
            Team team = new Team();

            Console.WriteLine("Enter Name:");
            team.Name = Console.ReadLine();
            Console.WriteLine("Enter SportId:");
            team.SportId = Display.GetIntNumber(team.SportId);
            Console.WriteLine("Enter TrainerId:");
            team.TrainerId = Display.GetIntNumber(team.TrainerId);
            teamBusiness.Add(team);            
        }

        /// <summary>
        /// Method "Update" finds an existing team and changes the information about it
        /// </summary>
        private void Update()
        {
            Console.WriteLine("Enter Id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Team team = teamBusiness.Get(id);

            if (team != null)
            {
                Console.WriteLine("Enter new name:");
                team.Name = Console.ReadLine();
                Console.WriteLine("Enter new sport id:");
                team.SportId = Display.GetIntNumber(team.SportId);
                Console.WriteLine("Enter new trainer id:");
                team.TrainerId = Display.GetIntNumber(team.TrainerId);
                teamBusiness.Update(team);
            }
            else
            {
                Console.WriteLine("Team not found");
            }
        }

        /// <summary>
        /// Method "FetchById" finds an existing team to which the given id matches and shows the information about it
        /// </summary>
        private void FetchById()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Team team = teamBusiness.Get(id);

            if (team != null)
            {
                Console.WriteLine($"Id: {team.Id}");
                Console.WriteLine($"Name: {team.Name}");
                var sport = sportBusiness.Get(team.SportId);
                Console.WriteLine($"Sport: {sport.Name}");
                var trainer = trainerBusiness.Get(team.TrainerId);
                Console.WriteLine($"Trainer: {trainer.Name}");
            }
            else
            {
                Console.WriteLine("Team not found");
            }
        }

        /// <summary>
        /// Method "FetchByName" finds an existing team to which the given name matches and shows the information about it
        /// </summary>
        private void FetchByName()
        {
            Console.WriteLine("Enter name:");
            string name = Console.ReadLine();
            List<Team> teams = teamBusiness.Get(name);

            if (teams.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Name", "Sport", "Trainer");

                foreach (var item in teams)
                {
                    var sport = sportBusiness.Get(item.SportId);
                    var trainer = trainerBusiness.Get(item.TrainerId);
                    table.AddRow(item.Id, item.Name, sport.Name, trainer.Name);
                }

                table.Write();
            }
            else
            {
                Console.WriteLine("No teams with such name");
            }
        }

        /// <summary>
        /// Method "Delete" finds an existing team and deletes it
        /// </summary>
        private void Delete()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            teamBusiness.Delete(id);
        }
    }
}
