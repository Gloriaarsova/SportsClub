﻿using System;
using System.Collections.Generic;
using SportsClub.Data.Models;
using SportsClub.Business;
using SportsClub.Data;

namespace SportsClub.Presentation
{
    /// <summary>
    /// In class "Display" are implemented the Menu and the methods, by which the entered information is taken
    /// </summary>
    public static class Display
    {
        public static int actionExitOperation = 7; 
        private static int tablesExitOperation = 6;

        private static PlayerDisplay playerDisplay;
        private static TeamDisplay teamDisplay;
        private static TrainerDisplay trainerDisplay;
        private static SportDisplay sportDisplay;
        private static GameDisplay gameDisplay;

        /// <summary>
        /// Method "GetInput" allows us to use the functions of the table we choose
        /// </summary>
        public static void GetInput()
        {
            var operation = -1;

            do
            {
                ShowTableNames();

                try
                {
                    operation = GetIntNumber(operation); //gets the number which we entered

                    switch (operation)
                    {
                        case 1:
                            {
                                playerDisplay = new PlayerDisplay();                               
                                break;
                            }
                        case 2:
                            {
                                teamDisplay = new TeamDisplay();
                                break;
                            }
                        case 3:
                            {
                                trainerDisplay = new TrainerDisplay();
                                break;
                            }
                        case 4:
                            {
                                sportDisplay = new SportDisplay();
                                break;
                            }
                        case 5:
                            {
                                gameDisplay = new GameDisplay();
                                break;
                            }
                        default:
                            {
                                if (operation != tablesExitOperation) //checks if the number which we eneterd in not in the menu
                                {
                                    Console.WriteLine("Not an operation number");
                                    GetBackToMenu();
                                }                                
                                break;                                
                            }
                    }
                }
                catch (ArgumentException exception)
                {
                    Console.WriteLine(exception.Message);
                    GetBackToMenu();
                }
            } while (operation != tablesExitOperation);
        }

        /// <summary>
        /// Method "ShowActions" shows a list of action to choose from
        /// </summary>
        public static void ShowActions()
        {
            Console.WriteLine("Choose action:");
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Fetch entry by name");
            Console.WriteLine("7. Exit");
            Console.Write("Enter operation number: ");
        }

        /// <summary>
        /// Method "ShowTableNames" shows a list of the tables names to choose from
        /// </summary>
        private static void ShowTableNames()
        {
            Console.Clear();
            Console.WriteLine("-- Sports Club --");
            Console.WriteLine("Choose table:");
            Console.WriteLine("1. Players");
            Console.WriteLine("2. Teams");
            Console.WriteLine("3. Trainers");
            Console.WriteLine("4. Sports");
            Console.WriteLine("5. Games");
            Console.WriteLine("6. Exit");
            Console.Write("Enter operation number: ");
        }

        /// <summary>
        /// Method "GetIntNumber" returns the number which we entered
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static int GetIntNumber(int number)
        {
            try
            {
                number = int.Parse(Console.ReadLine());
                return number;
            }
            catch
            {
                throw new ArgumentException("This should be written with numbers only");
            }
        }

        /// <summary>
        /// Method "GetIntNumber" returns the number which we entered
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static int? GetIntNumber(int? number)
        {
            try
            {
                number = int.Parse(Console.ReadLine());
                return number;
            }
            catch
            {
                throw new ArgumentException("This should be written with numbers only");
            }
        }

        /// <summary>
        /// Method "GetBackToMenu" bring us back to the Menu
        /// </summary>
        public static void GetBackToMenu()
        {
            Console.WriteLine();
            Console.WriteLine("Press enter to go back...");
            Console.ReadLine();
        }
    }
}
