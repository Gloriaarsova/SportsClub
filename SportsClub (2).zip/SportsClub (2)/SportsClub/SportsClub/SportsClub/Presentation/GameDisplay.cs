﻿using ConsoleTables;
using SportsClub.Business;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SportsClub.Presentation
{
    /// <summary>
    /// In class "GameDisplay" are implemented the methods, which describe how the game information is displayed
    /// </summary>
    public class GameDisplay
    {
        private TeamBusiness teamBusiness = new TeamBusiness();
        private GameBusiness gameBusiness = new GameBusiness();

        /// <summary>
        /// Method "GameDisplay" allows us to use the functions we choose
        /// </summary>
        public GameDisplay()
        {
            var operation = -1;

            do
            {
                Console.Clear();
                Console.WriteLine("-- Games --");
                Display.ShowActions();

                try
                {
                    operation = Display.GetIntNumber(operation); //gets the number which we entered

                    Console.Clear();

                    switch (operation)
                    {
                        case 1:
                            {
                                ListAll();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 2:
                            {
                                Add();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 3:
                            {
                                Update();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 4:
                            {
                                FetchById();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 5:
                            {
                                Delete();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 6:
                            {
                                FetchByName();
                                Display.GetBackToMenu();
                                break;
                            }
                        default:
                            {
                                if (operation != Display.actionExitOperation)//checks if the number which we eneterd in not in the menu
                                {
                                    Console.WriteLine("Not an operation number");
                                    Display.GetBackToMenu();
                                }
                                break;
                            }
                    }
                }
                catch (ArgumentException exception)
                {
                    Console.WriteLine(exception.Message);
                    Display.GetBackToMenu();
                }
            } while (operation != Display.actionExitOperation);
        }

        /// <summary>
        /// Method "ListAll" shows a list of all games and the information about them
        /// </summary>
        private void ListAll()
        {
            Console.WriteLine("Games:");
            List<Game> games = gameBusiness.GetAll();

            if (games.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Match");

                foreach (var item in games)
                {
                    var team1 = teamBusiness.Get(item.FirstTeamId);
                    var team2 = teamBusiness.Get(item.SecondTeamId);
                    table.AddRow(item.Id, $"{team1.Name} vs {team2.Name}");
                }

                table.Write();
            }
            else
            {
                Console.WriteLine("No games");
            }
        }

        /// <summary>
        /// Method "Add" adds a new game to the database
        /// </summary>
        private void Add()
        {
            Game game = new Game();
            Console.WriteLine("Enter First Team Id:");
            game.FirstTeamId = Display.GetIntNumber(game.FirstTeamId);
            Console.WriteLine("Enter Second Team Id:");
            game.SecondTeamId = Display.GetIntNumber(game.SecondTeamId);
            gameBusiness.Add(game);
        }

        /// <summary>
        /// Method "Update" finds an existing game and changes the information about it
        /// </summary>
        private void Update()
        {
            Console.WriteLine("Enter Id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Game game = gameBusiness.Get(id);

            if (game != null)
            {
                Console.WriteLine("Enter new first team id:");
                game.FirstTeamId = Display.GetIntNumber(game.FirstTeamId);
                Console.WriteLine("Enter new second team id:");
                game.SecondTeamId = Display.GetIntNumber(game.SecondTeamId);

                gameBusiness.Update(game);
            }
            else
            {
                Console.WriteLine("Game not found");
            }
        }

        /// <summary>
        /// Method "FetchById" finds an existing game to which the given id matches and shows the information about it
        /// </summary>
        private void FetchById()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Game game = gameBusiness.Get(id);

            if (game != null)
            {
                Console.WriteLine();
                Console.WriteLine($"Id: {game.Id}");
                var team1 = teamBusiness.Get(game.FirstTeamId);
                var team2 = teamBusiness.Get(game.SecondTeamId);
                Console.WriteLine($"Match: {team1.Name} vs {team2.Name}");
            }
            else
            {
                Console.WriteLine("Game not found");
            }
        }

        /// <summary>
        /// Method "FetchByName" finds an existing game to which the given name matches and shows the information about it
        /// </summary>
        private void FetchByName()
        {
            Console.WriteLine("Games don't have names");
        }

        /// <summary>
        /// Method "Delete" finds an existing game and deletes it
        /// </summary>
        private void Delete()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            gameBusiness.Delete(id);
        }
    }
}
