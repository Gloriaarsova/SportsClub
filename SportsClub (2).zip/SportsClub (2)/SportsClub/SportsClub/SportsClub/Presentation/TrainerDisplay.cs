﻿using ConsoleTables;
using SportsClub.Business;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SportsClub.Presentation
{
    /// <summary>
    /// In class "TrainerDisplay" are implemented the methods, which describe how the trainer information is displayed
    /// </summary>
    public class TrainerDisplay
    {
        private TrainerBusiness trainerBusiness = new TrainerBusiness();

        /// <summary>
        /// Method "TrainerDisplay" allows us to use the functions we choose
        /// </summary>
        public TrainerDisplay()
        {
            var operation = -1;

            do
            {
                Console.Clear();
                Console.WriteLine("-- Trainers --");
                Display.ShowActions();

                try
                {
                    operation = Display.GetIntNumber(operation);//gets the number which we entered

                    Console.Clear();

                    switch (operation)
                    {
                        case 1:
                            {
                                ListAll();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 2:
                            {
                                Add();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 3:
                            {
                                Update();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 4:
                            {
                                FetchById();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 5:
                            {
                                Delete();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 6:
                            {
                                FetchByName();
                                Display.GetBackToMenu();
                                break;
                            }
                        default:
                            {
                                if (operation != Display.actionExitOperation)//checks if the number which we eneterd in not in the menu
                                {
                                    Console.WriteLine("Not an operation number");
                                    Display.GetBackToMenu();
                                }
                                break;
                            }
                    }
                }
                catch (ArgumentException exception)
                {
                    Console.WriteLine(exception.Message);
                    Display.GetBackToMenu();
                }
            } while (operation != Display.actionExitOperation);
        }

        /// <summary>
        /// Method "ListAll" shows a list of all trainers and the information about them
        /// </summary>
        private void ListAll()
        {
            Console.WriteLine("Trainers:");
            List<Trainer> trainers = trainerBusiness.GetAll();

            if (trainers.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Name");

                foreach (var item in trainers)
                {
                    table.AddRow(item.Id, item.Name);                    
                }

                table.Write();
            }
            else
            {
                Console.WriteLine("No trainers");
            }
        }

        /// <summary>
        /// Method "Add" adds a new trainer to the database
        /// </summary>
        private void Add()
        {
            Trainer trainer = new Trainer();

            Console.WriteLine("Enter Name:");
            trainer.Name = Console.ReadLine();
            trainerBusiness.Add(trainer);
        }

        /// <summary>
        /// Method "Update" finds an existing trainer and changes the information about him
        /// </summary>
        private void Update()
        {
            Console.WriteLine("Enter Id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Trainer trainer = trainerBusiness.Get(id);

            if (trainer != null)
            {
                Console.WriteLine("Enter new name:");
                trainer.Name = Console.ReadLine();
                trainerBusiness.Update(trainer);
            }
            else
            {
                Console.WriteLine("Trainer not found");
            }
        }

        /// <summary>
        /// Method "FetchById" finds an existing trainer to which the given id matches and shows the information about him
        /// </summary>
        private void FetchById()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Trainer trainer = trainerBusiness.Get(id);

            if (trainer != null)
            {
                Console.WriteLine($"Id: {trainer.Id}");
                Console.WriteLine($"Name: {trainer.Name}");
            }
            else
            {
                Console.WriteLine("Trainer not found");
            }
        }

        /// <summary>
        /// Method "FetchByName" finds an existing trainer to which the given name matches and shows the information about him
        /// </summary>
        private void FetchByName()
        {
            Console.WriteLine("Enter name:");
            string name = Console.ReadLine();
            List<Trainer> trainers = trainerBusiness.Get(name);

            if (trainers.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Name");

                foreach (var item in trainers)
                {
                    table.AddRow(item.Id, item.Name);
                }

                table.Write();
            }
            else
            {
                Console.WriteLine("No trainers with such name");
            }
        }

        /// <summary>
        /// Method "Delete" finds an existing trainer and deletes him
        /// </summary>
        private void Delete()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            trainerBusiness.Delete(id);
        }
    }
}
