﻿using ConsoleTables;
using SportsClub.Business;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SportsClub.Presentation
{
    /// <summary>
    /// In class "PlayerDisplay" are implemented the methods, which describe how the player information is displayed
    /// </summary>
    public class PlayerDisplay
    {
        private PlayerBusiness playerBusiness = new PlayerBusiness();
        private TeamBusiness teamBusiness = new TeamBusiness();

        /// <summary>
        /// Method "PlayerDisplay" allows us to use the functions we choose
        /// </summary>
        public PlayerDisplay()
        {
            var operation = -1;

            do
            {
                Console.Clear();
                Console.WriteLine("-- Players --");
                Display.ShowActions();

                try
                {
                    operation = Display.GetIntNumber(operation);//gets the number which we entered

                    Console.Clear();

                    switch (operation)
                    {
                        case 1:
                            {
                                ListAll();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 2:
                            {
                                Add();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 3:
                            {
                                Update();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 4:
                            {
                                FetchById();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 5:
                            {
                                Delete();
                                Display.GetBackToMenu();
                                break;
                            }
                        case 6:
                            {
                                FetchByName();
                                Display.GetBackToMenu();
                                break;
                            }
                        default:
                            {
                                if (operation != Display.actionExitOperation)//checks if the number which we eneterd in not in the menu
                                {
                                    Console.WriteLine("Not an operation number");
                                    Display.GetBackToMenu();
                                }
                                break;
                            }
                    }
                }
                catch (ArgumentException exception)
                {
                    Console.WriteLine(exception.Message);
                    Display.GetBackToMenu();
                }
            } while (operation != Display.actionExitOperation);
        }

        /// <summary>
        /// Method "ListAll" shows a list of all players and the information about them
        /// </summary>
        private void ListAll()
        {
            Console.WriteLine("Players:");
            List<Player> players = playerBusiness.GetAll();

            if (players.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Name", "Age", "Team");

                foreach (var item in players)
                {
                    var team = teamBusiness.Get(item.TeamId);
                    table.AddRow(item.Id, item.Name, item.Age, team.Name);
                }

                table.Write();
            }
            else
            {
                Console.WriteLine("No players");
            }
        }

        /// <summary>
        /// Method "Add" adds a new player to the database
        /// </summary>
        private void Add()
        {
            Player player = new Player();
            Console.WriteLine("Enter Name:");
            player.Name = Console.ReadLine();
            Console.WriteLine("Enter Age:");
            player.Age = Display.GetIntNumber(player.Age);
            Console.WriteLine("Enter TeamId:");
            player.TeamId = Display.GetIntNumber(player.TeamId);
            playerBusiness.Add(player);
        }

        /// <summary>
        /// Method "Update" finds an existing player and changes the information about him
        /// </summary>
        private void Update()
        {
            Console.WriteLine("Enter Id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Player player = playerBusiness.Get(id);

            if (player != null)
            {
                Console.WriteLine("Enter new name:");
                player.Name = Console.ReadLine();
                Console.WriteLine("Enter new age:");
                player.Age = Display.GetIntNumber(player.Age);
                Console.WriteLine("Enter new team id:");
                player.TeamId = Display.GetIntNumber(player.TeamId);

                playerBusiness.Update(player);
            }
            else
            {
                Console.WriteLine("Player not found");
            }
        }

        /// <summary>
        /// Method "FetchById" finds an existing player to which the given id matches and shows the information about him
        /// </summary>
        private void FetchById()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            Player player = playerBusiness.Get(id);

            if (player != null)
            {
                Console.WriteLine($"Id: {player.Id}");
                Console.WriteLine($"Name: {player.Name}");
                Console.WriteLine($"Age: {player.Age}");
                var team = teamBusiness.Get(player.TeamId);
                Console.WriteLine($"Team: {team.Name}");
            }
            else
            {
                Console.WriteLine("Player not found");
            }
        }

        /// <summary>
        /// Method "FetchByName" finds an existing player to which the given name matches and shows the information about him
        /// </summary>
        private void FetchByName()
        {
            Console.WriteLine("Enter name:");
            string name = Console.ReadLine();
            List<Player> players = playerBusiness.Get(name);

            if (players.Count != 0)
            {
                Console.WriteLine();
                var table = new ConsoleTable("Id", "Name", "Age", "Team");

                foreach (var item in players)
                {
                    var team = teamBusiness.Get(item.TeamId);
                    table.AddRow(item.Id, item.Name, item.Age, team.Name);
                }

                table.Write();
            }
            else
            {
                Console.WriteLine("No players with such name");
            }
        }

        /// <summary>
        /// Method "Delete" finds an existing player and deletes him
        /// </summary>
        private void Delete()
        {
            Console.WriteLine("Enter id:");
            int id = 0;
            id = Display.GetIntNumber(id);
            playerBusiness.Delete(id);
        }
    }
}
