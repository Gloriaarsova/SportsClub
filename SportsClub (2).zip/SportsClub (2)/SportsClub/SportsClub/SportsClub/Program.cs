﻿using SportsClub.Presentation;
using System;

namespace SportsClub
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
            Display.GetInput();
        }
    }
}
