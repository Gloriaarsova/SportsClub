﻿using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using SportsClub.Business;
using SportsClub.Data;
using SportsClub.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SportsClubTests
{
    public class Tests
    {
        private const string connection = "Server = .\\SQLEXPRESS; Database= SportsClubTest; Integrated Security=True;";
        private PlayerBusiness playerBusiness;
        private TeamBusiness teamBusiness;
        private TrainerBusiness trainerBusiness;
        private SportBusiness sportBusiness;
        private GameBusiness gameBusiness;

        [SetUp]
        public void SetUp()
        {
            playerBusiness = new PlayerBusiness(connection);
            teamBusiness = new TeamBusiness(connection);
            trainerBusiness = new TrainerBusiness(connection);
            sportBusiness = new SportBusiness(connection);
            gameBusiness = new GameBusiness(connection);

            EmptyTestDB();
        }        
        
        public void EmptyTestDB()
        {
            var players = playerBusiness.GetAll();
            players.ForEach(player => playerBusiness.Delete(player.Id));

            var games = gameBusiness.GetAll();
            games.ForEach(game => gameBusiness.Delete(game.Id));

            var teams = teamBusiness.GetAll();
            teams.ForEach(team => teamBusiness.Delete(team.Id));
            
            var trainers = trainerBusiness.GetAll();
            trainers.ForEach(trainer => trainerBusiness.Delete(trainer.Id));

            var sports = sportBusiness.GetAll();
            sports.ForEach(sport => sportBusiness.Delete(sport.Id));
        }

        [Test]
        public void AddPlayerAddsPlayer()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();
                int expectedCount = 1;

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam",sportId,trainerId);
                teamBusiness.Add(team);
                var teamId = teamBusiness.Get(team.Name)[0].Id;

                var player = new Player("testPlayer", 25, teamId);
                playerBusiness.Add(player);

                var players = playerBusiness.GetAll();
                Player createdPlayer = players.Skip(players.Count - 1).ToList()[0];

                Assert.That(expectedCount == players.Count());
                Assert.That(player.Name == createdPlayer.Name);
                Assert.That(player.Age == createdPlayer.Age);
                Assert.That(player.TeamId == createdPlayer.TeamId);
            }
        }

        [Test]
        public void AddSportAddsSportWhenSportDoesntExist()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();
                int expectedCount = 1;

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sports = sportBusiness.GetAll();
                Sport createdSport = sports.Skip(sports.Count - 1).ToList()[0];

                Assert.That(expectedCount == sports.Count());
                Assert.That(sport.Name == createdSport.Name);
            }
        }

        [Test]
        public void AddSportDoentAddSportWhenSportExists()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);

                try
                {
                    sportBusiness.Add(sport);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }                                        
            }
        }

        [Test]
        public void AddTrainerAddsTrainer()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();
                int expectedCount = 1;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainers = trainerBusiness.GetAll();
                Trainer createdTrainer = trainers.Skip(trainers.Count - 1).ToList()[0];

                Assert.That(expectedCount == trainers.Count());
                Assert.That(trainer.Name == createdTrainer.Name);
            }
        }

        [Test]
        public void AddTeamAddsTeamWhenTeamDoesntExist()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();
                int expectedCount = 1;

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);

                var teams = teamBusiness.GetAll();
                Team createdTeam = teams.Skip(teams.Count - 1).ToList()[0];

                Assert.That(expectedCount == teams.Count());
                Assert.That(team.Name == createdTeam.Name);
                Assert.That(team.SportId == createdTeam.SportId);
                Assert.That(team.TrainerId == createdTeam.TrainerId);
            }
        }

        [Test]
        public void AddTeamDoesntAddTeamWhenTeamExists()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();
                int expectedCount = 1;

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);

                try
                {
                    teamBusiness.Add(team);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }

        [Test]
        public void AddGameAddsGame()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();
                int expectedCount = 1;

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer1");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team1 = new Team("testTeam1", sportId, trainerId);
                teamBusiness.Add(team1);

                trainer = new Trainer("testTrainer2");
                trainerBusiness.Add(trainer);
                trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team2 = new Team("testTeam2", sportId, trainerId);
                teamBusiness.Add(team2);

                var team1Id = teamBusiness.Get(team1.Name)[0].Id;
                var team2Id = teamBusiness.Get(team2.Name)[0].Id;

                var game = new Game(team1Id, team2Id);
                gameBusiness.Add(game);
                var games = gameBusiness.GetAll();
                Game createdGame = games.Skip(games.Count() - 1).ToList()[0];

                Assert.That(expectedCount == games.Count());
                Assert.That(game.FirstTeamId == createdGame.FirstTeamId);
                Assert.That(game.SecondTeamId == createdGame.SecondTeamId);
            }
        }

        [Test]
        public void GetAllPlayersReturnsCorrectList()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                var players = playerBusiness.GetAll();
                var expectedPlayers = sportsClubContext.Players.ToList();
                bool listsAreTheSame = true;

                for (int i=0;i<players.Count();i++)
                {
                    if (players[i] != expectedPlayers[i])
                    {
                        listsAreTheSame = false;
                        break;
                    }
                }
                Assert.That(listsAreTheSame);
            }
        }

        [Test]
        public void GetAllSportsReturnsCorrectList()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                var sports = sportBusiness.GetAll();
                var expectedSports = sportsClubContext.Sports.ToList();
                bool listsAreTheSame = true;

                for (int i = 0; i < sports.Count(); i++)
                {
                    if (sports[i] != expectedSports[i])
                    {
                        listsAreTheSame = false;
                        break;
                    }
                }
                Assert.That(listsAreTheSame);
            }
        }

        [Test]
        public void GetAllGamesReturnsCorrectList()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                var games = gameBusiness.GetAll();
                var expectedGames = sportsClubContext.Games.ToList();
                bool listsAreTheSame = true;

                for (int i = 0; i < games.Count(); i++)
                {
                    if (games[i] != expectedGames[i])
                    {
                        listsAreTheSame = false;
                        break;
                    }
                }
                Assert.That(listsAreTheSame);
            }
        }

        [Test]
        public void GetAllTrainersReturnsCorrectList()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                var trainers = trainerBusiness.GetAll();
                var expectedTrainers = sportsClubContext.Trainers.ToList();
                bool listsAreTheSame = true;

                for (int i = 0; i < trainers.Count(); i++)
                {
                    if (trainers[i] != expectedTrainers[i])
                    {
                        listsAreTheSame = false;
                        break;
                    }
                }
                Assert.That(listsAreTheSame);
            }
        }

        [Test]
        public void GetAllTeamsReturnsCorrectList()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                var teams = teamBusiness.GetAll();
                var expectedTeams = sportsClubContext.Teams.ToList();
                bool listsAreTheSame = true;

                for (int i = 0; i < teams.Count(); i++)
                {
                    if (teams[i] != expectedTeams[i])
                    {
                        listsAreTheSame = false;
                        break;
                    }
                }
                Assert.That(listsAreTheSame);
            }
        }

        [Test]
        public void DeletePlayerDeletesPlayer()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);
                var teamId = teamBusiness.Get(team.Name)[0].Id;

                var player = new Player("testPlayer", 25, teamId);
                playerBusiness.Add(player);

                var players = playerBusiness.GetAll();
                Player createdPlayer = players.Skip(players.Count - 1).ToList()[0];
                playerBusiness.Delete(createdPlayer.Id);
                player = playerBusiness.Get(createdPlayer.Id);

                Assert.That(player == null);
            }
        }

        [Test]
        public void DeleteSportDeletesSport()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sports = sportBusiness.GetAll();
                Sport createdSport = sports.Skip(sports.Count - 1).ToList()[0];
                sportBusiness.Delete(createdSport.Id);
                sport = sportBusiness.Get(createdSport.Id);

                Assert.That(sport == null);
            }
        }

        [Test]
        public void DeleteTrainerDeletesTrainer()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainers = trainerBusiness.GetAll();
                Trainer createdTrainer = trainers.Skip(trainers.Count - 1).ToList()[0];
                trainerBusiness.Delete(createdTrainer.Id);
                trainer = trainerBusiness.Get(createdTrainer.Id);

                Assert.That(trainer == null);
            }
        }

        [Test]
        public void DeleteTeamDeletesTeam()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);

                var teams = teamBusiness.GetAll();
                Team createdTeam = teams.Skip(teams.Count - 1).ToList()[0];
                teamBusiness.Delete(createdTeam.Id);
                team = teamBusiness.Get(createdTeam.Id);

                Assert.That(team == null);
            }
        }

        [Test]
        public void DeleteGameDeletesGame()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer1");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team1 = new Team("testTeam1", sportId, trainerId);
                teamBusiness.Add(team1);

                trainer = new Trainer("testTrainer2");
                trainerBusiness.Add(trainer);
                trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team2 = new Team("testTeam2", sportId, trainerId);
                teamBusiness.Add(team2);

                var team1Id = teamBusiness.Get(team1.Name)[0].Id;
                var team2Id = teamBusiness.Get(team2.Name)[0].Id;

                var game = new Game(team1Id, team2Id);
                gameBusiness.Add(game);
                var games = gameBusiness.GetAll();
                Game createdGame = games.Skip(games.Count() - 1).ToList()[0];
                gameBusiness.Delete(createdGame.Id);
                game = gameBusiness.Get(createdGame.Id);

                Assert.That(game == null);
            }
        }

        [Test]
        public void GetPlayerReturnsCorrectPlayer()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);
                var teamId = teamBusiness.Get(team.Name)[0].Id;

                var player = new Player("testPlayer", 25, teamId);
                playerBusiness.Add(player);

                var players = playerBusiness.GetAll();
                Player createdPlayer = players.Skip(players.Count - 1).ToList()[0];
                player = playerBusiness.Get(createdPlayer.Id);

                Assert.That(player.Id == createdPlayer.Id);
                Assert.That(player.Name == createdPlayer.Name);
                Assert.That(player.Age == createdPlayer.Age);
                Assert.That(player.TeamId == createdPlayer.TeamId);
            }
        }

        [Test]
        public void GetSportReturnsCorrectSport()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sports = sportBusiness.GetAll();
                Sport createdSport = sports.Skip(sports.Count - 1).ToList()[0];
                sport = sportBusiness.Get(createdSport.Id);

                Assert.That(sport.Id == createdSport.Id);
                Assert.That(sport.Name == createdSport.Name);
            }
        }

        [Test]
        public void GetTrainerReturnsCorrectTrainer()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainers = trainerBusiness.GetAll();
                Trainer createdTrainer = trainers.Skip(trainers.Count - 1).ToList()[0];
                trainer = trainerBusiness.Get(createdTrainer.Id);

                Assert.That(trainer.Id == createdTrainer.Id);
                Assert.That(trainer.Name == createdTrainer.Name);
            }
        }

        [Test]
        public void GetTeamReturnsCorrectTeam()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);

                var teams = teamBusiness.GetAll();
                Team createdTeam = teams.Skip(teams.Count - 1).ToList()[0];
                team = teamBusiness.Get(createdTeam.Id);

                Assert.That(team.Id == createdTeam.Id);
                Assert.That(team.Name == createdTeam.Name);
                Assert.That(team.SportId == createdTeam.SportId);
                Assert.That(team.TrainerId == createdTeam.TrainerId);
            }
        }

        [Test]
        public void GetGameReturnsCorrectGame()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer1");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team1 = new Team("testTeam1", sportId, trainerId);
                teamBusiness.Add(team1);

                trainer = new Trainer("testTrainer2");
                trainerBusiness.Add(trainer);
                trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team2 = new Team("testTeam2", sportId, trainerId);
                teamBusiness.Add(team2);

                var team1Id = teamBusiness.Get(team1.Name)[0].Id;
                var team2Id = teamBusiness.Get(team2.Name)[0].Id;

                var game = new Game(team1Id, team2Id);
                gameBusiness.Add(game);
                var games = gameBusiness.GetAll();
                Game createdGame = games.Skip(games.Count() - 1).ToList()[0];
                game = gameBusiness.Get(createdGame.Id);

                Assert.That(game.Id == createdGame.Id);
                Assert.That(game.FirstTeamId == createdGame.FirstTeamId);
                Assert.That(game.SecondTeamId == createdGame.SecondTeamId);
            }
        }        

        [Test]
        public void AddSportDoentAddSportWhenNameIsNull()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport(null);

                try
                {
                    sportBusiness.Add(sport);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }

        [Test]
        public void AddSportDoentAddSportWhenNameIsEmpty()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("");

                try
                {
                    sportBusiness.Add(sport);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }

        [Test]
        public void AddTrainerDoentAddTrainerWhenNameIsEmpty()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var trainer = new Trainer("");

                try
                {
                    trainerBusiness.Add(trainer);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }                                
            }
        }

        [Test]
        public void AddTrainerDoentAddTrainerWhenNameIsNull()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var trainer = new Trainer(null);

                try
                {
                    trainerBusiness.Add(trainer);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }

        [Test]
        public void AddPlayerDoentAddPlayerWhenNameIsNull()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);
                var teamId = teamBusiness.Get(team.Name)[0].Id;

                var player = new Player(null, 25, teamId);

                try
                {
                    playerBusiness.Add(player);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }                
            }
        }

        [Test]
        public void AddPlayerDoentAddPlayerWhenNameIsEmpty()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("testTeam", sportId, trainerId);
                teamBusiness.Add(team);
                var teamId = teamBusiness.Get(team.Name)[0].Id;

                var player = new Player("", 25, teamId);

                try
                {
                    playerBusiness.Add(player);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }

        [Test]
        public void AddTeamDoentAddTeamWhenNameIsEmpty()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team("", sportId, trainerId);

                try
                {
                    teamBusiness.Add(team);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }

        [Test]
        public void AddTeamDoentAddTeamWhenNameIsNull()
        {
            using (var sportsClubContext = new SportsClubContext(connection))
            {
                EmptyTestDB();

                var sport = new Sport("testSport");
                sportBusiness.Add(sport);
                var sportId = sportBusiness.Get(sport.Name).Id;

                var trainer = new Trainer("testTrainer");
                trainerBusiness.Add(trainer);
                var trainerId = trainerBusiness.Get(trainer.Name)[0].Id;

                var team = new Team(null, sportId, trainerId);

                try
                {
                    teamBusiness.Add(team);

                    Assert.That(false);
                }
                catch
                {
                    Assert.That(true);
                }
            }
        }
    }
}
